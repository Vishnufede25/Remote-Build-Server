﻿////////////////////////////////////////////////////////////////////////
// TestRequest.cs - build and parse test requests                     //
// Platform:    MSI , Windows 10, Visual Studio 2017                  //
// Author:      Vishnu Prasad Vishwanathan                            //
// Referenece:  Jim Fawcett                                           //
// SUID:        793782749                                             //
//             (315)382-9922,                                         //
//              vvishwan@syr.edu                                      //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017    //
////////////////////////////////////////////////////////////////////////
/*
 *  Package Operations:
 * -------------------
 * The Primary functions of Test Request:
 * 1. Create test request XML Files.
 * 2. Parsing these Tests
 *   
 * Public Interface:
 * -------------------
 * This package contains a class TestRequest with functions:
 * - makeRequest    : build XML document that represents a test request 
 * - loadXml        : load TestRequest from XML file 
 * - saveXml        : save TestRequest to XML file
 * - parse          : parse document for property value 
 * - parseTestList  : parse document for Test list
 * - parseDLLList        : Creating WCF Send and Receive messages
 * 
 * Required Files:
 * ---------------
 *  
 * Maintenance History:
 * --------------------
 * ver 1.0 : 08 Dec 2017
 * - first release
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Federation
{
    ///////////////////////////////////////////////////////////////////
    // Test class
    public class test
    {
        public string testName { get; set; } = "";
        public string testDriver { get; set; } = "";
        public List<string> testedFiles { get; set; } = new List<string>();
        public test()
        {
            testName = "";
            testDriver = "";
            testedFiles.RemoveRange(0,testedFiles.Count());
        }
    }

    //DLL Class
    public class test_dll
    {
        public string testName { get; set; } = "";
        public string dllName { get; set; } = "";
    }

    // TestRequest class
    public class TestRequest
    {
        public string author { get; set; } = "";
        public string dateTime { get; set; } = "";
        public List<test> test_list = new List<test>();
        public List<test_dll> tes_dlls = new List<test_dll>();
        public XDocument doc { get; set; } = new XDocument();

        /*----< build XML document that represents a test request >----*/
        public XDocument makeRequest(string author, string[] testNames, List<string> dllNames)
        {
            XElement testRequestElem = new XElement("testRequest");
            doc.Add(testRequestElem);

            XElement authorElem = new XElement("author");
            authorElem.Add(author);
            testRequestElem.Add(authorElem);

            XElement dateTimeElem = new XElement("dateTime");
            dateTimeElem.Add(DateTime.Now.ToString());
            testRequestElem.Add(dateTimeElem);

            for (int i = 0; i < testNames.Length; i++)
            {
                XElement testElem = new XElement("test");
                testRequestElem.Add(testElem);
                XElement testNameElem = new XElement("testName");
                testNameElem.Add(testNames[i]);
                testElem.Add(testNameElem);
                XElement dllElem = new XElement("dllName");
                dllElem.Add(dllNames[i]);
                testElem.Add(dllElem);
            }
            Console.WriteLine("\nCreated the Test Request for the current Build Request");
            return doc;
        }


        /*----< load TestRequest from XML file >-----------------------*/
        public bool loadXml(string path)
        {
            try
            {
                doc = XDocument.Load(path);
                return true;
            }
            catch (Exception ex)
            {
                Console.Write("\n--{0}--\n", ex.Message);
                return false;
            }
        }


        /*----< save TestRequest to XML file >-------------------------*/
        public bool saveXml(string path)
        {
            try
            {
                doc.Save(path);
                return true;
            }
            catch (Exception ex)
            {
                Console.Write("\n--{0}--\n", ex.Message);
                return false;
            }
        }


        /*----< parse document for property value >--------------------*/
        public string parse(string propertyName)
        {
            string parseStr = doc.Descendants(propertyName).First().Value;
            if (parseStr.Length > 0)
            {
                switch (propertyName)
                {
                    case "author":
                        author = parseStr;
                        break;
                    case "dateTime":
                        dateTime = parseStr;
                        break;
                    default:
                        break;
                }
                return parseStr;
            }
            return "";
        }

        /*----< parse document for Test list >---------------------*/
        public List<test> parseTestList(string propertyName)
        {
            List<test> values = new List<test>();
            IEnumerable<XElement> parseElems = doc.Descendants(propertyName);
            //getting all the data of one test
            if (parseElems.Count() > 0)                                                    
            {
                switch (propertyName)
                {
                    case "test":
                        foreach (XElement elem in parseElems)
                        {   test t1 = new test();
                            IEnumerable<XElement> parseElemsTest = elem.Descendants("testName");
                            if (elem.Descendants("testName").First().Value != null)
                                t1.testName = elem.Descendants("testName").First().Value;
                            List<string> values_test = new List<string>();
                            IEnumerable<XElement> parseElemsTest1 = elem.Descendants("testDriver");
                            string parseStr = elem.Descendants("testDriver").First().Value;
                            if (parseStr != null)
                            {
                                t1.testDriver = parseStr;
                            }
                            IEnumerable<XElement> parseElemsTest2 = elem.Descendants("tested");
                            if (parseElemsTest2.Count() > 0)
                            {
                                foreach (XElement elem1 in parseElemsTest2)
                                {  values_test.Add(elem1.Value); }
                            }
                            IEnumerable<XElement> parseElemsTest3 = elem.Descendants("reference");
                            if (parseElemsTest3.Count() > 0)
                            {
                                foreach (XElement elem1 in parseElemsTest3)
                                {  values_test.Add(elem1.Value);  }                              
                            }
                            t1.testedFiles.AddRange(values_test);
                            values.Add(t1);
                        }
                        break;
                    default:
                        break;
                }
            }
            return values;
        }

        /*----< parse document for DLL list >---------------------*/
        public List<test_dll> parseDLLList(string propertyName)
        {
            List<test_dll> dll_values = new List<test_dll>();
            IEnumerable<XElement> parseElems = doc.Descendants(propertyName);
            //getting all the data of one DLL
            if (parseElems.Count() > 0)
            {
                switch (propertyName)
                {
                    case "test":
                        foreach (XElement elem in parseElems)
                        {
                            test_dll t2 = new test_dll();
                            IEnumerable<XElement> parseElemsTest = elem.Descendants("testName");
                            if (elem.Descendants("testName").First().Value != null)
                                t2.testName = elem.Descendants("testName").First().Value;
                            IEnumerable<XElement> parseElemsTest2 = elem.Descendants("dllName");
                            string parseStr1 = elem.Descendants("dllName").First().Value;
                            if (parseStr1 != null)
                            {  t2.dllName = parseStr1;  }
                            dll_values.Add(t2);
                        }
                        break;
                    default:
                        break;
                }
            }
            return dll_values;
        }
    }   
    
    ///////////////////////////////////////////////////////////////////
        // test_TestRequest class

        class Test_TestRequest
        {
            #if (TEST_X)
            static void Main(string[] args)
            {
                Console.Write("\n  Testing TestRequest");
                Console.Write("\n =====================");

                string savePath = "../../test/";
                string fileName = "TestRequest2.xml";

                if (!System.IO.Directory.Exists(savePath))
                    System.IO.Directory.CreateDirectory(savePath);
                string fileSpec = System.IO.Path.Combine(savePath, fileName);
                fileSpec = System.IO.Path.GetFullPath(fileSpec);

                TestRequest tr = new TestRequest();
                tr.author = "Jim Fawcett";
                tr.test_list[0].testDriver = "td1.cs";
                tr.test_list[0].testedFiles.Add("tf1.cs");
                tr.test_list[0].testedFiles.Add("tf2.cs");

                Console.Write("\n{0}", tr.doc.ToString());
                Console.Write("\n  saving to \"{0}\"", fileSpec);
                Console.Write("\n  reading from \"{0}\"", fileSpec);

                TestRequest tr2 = new TestRequest();

                Console.Write("\n{0}", tr2.doc.ToString());
                Console.Write("\n");

                tr2.parse("author");
                Console.Write("\n  author is \"{0}\"", tr2.author);

                tr2.parse("dateTime");
                Console.Write("\n  dateTime is \"{0}\"", tr2.dateTime);

                tr2.parseTestList("test");
                Console.Write("\n  testedFiles are:");
                for (int i = 0; i < tr2.test_list.Count(); i++)
                {

                    Console.WriteLine("\n  Test is \"{0}\"", tr2.test_list[i].testDriver);
                    foreach (string file in tr2.test_list[i].testedFiles)
                    {
                        Console.Write("\n    \"{0}\"", file);
                    }
                }
                Console.Write("\n\n");
            }
        }
#endif
    }

