﻿////////////////////////////////////////////////////////////////////////
// ChildProc.cs - Child Builder                                       //
// Platform:    MSI , Windows 10, Visual Studio 2017                  //
// Author:      Vishnu Prasad Vishwanathan                            //
// Referenece:  Jim Fawcett                                           //
// SUID:        793782749                                             //
//             (315)382-9922,                                         //
//              vvishwan@syr.edu                                      //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017    //
////////////////////////////////////////////////////////////////////////
/*
 *  Package Operations:
 * -------------------
 * The Primary functions of Child Builder:
 * 1.Send ready message to the mother builder and wait for the build request name
 * 2.After receiving the build request, send the filename to the RepoMock and 
 *   receive the Build request file
 * 3.Parse the build request and ask for the files to build it to RepoMock
 * 4.Receive the files
 * 
 * Public Interface:
 * -------------------
 * This package contains a single class ChildProc with functions:
 * - getFilesHelper    : function for getting files
 * - getFiles          : Finds all the files, matching pattern, in the entire directory 
 * - ParseStoreFiles   : Parsing the Build Request in CoreBuildServer
 * - sendFile          : File sending function
 * - CompileExecutable : Creating DLLs
 * - createMsg         : Creating WCF Send and Receive messages
 * - testComm          : Passing the created WCF Messages
 * 
 * Required Files:
 * ---------------
 * - IMessagePassingComm  - WCF Message Communication Interface
 * - MessagePassingComm   - WCF Message Communication Class
 * - TesRequest           - Test Request Creation
 * - TestUtilities        - Helper class that is used mostly for testing
 *  
 * Maintenance History:
 * --------------------
 * ver 1.0 : 08 Dec 2017
 * - first release
 * 
*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using Federation;
using System.ComponentModel;
using System.Threading;
using MessagePassingComm;
using System.IO;
using System.ServiceModel;
using System.Linq;
using System.Xml.Linq;
using System.CodeDom.Compiler;
using System.Globalization;


namespace ChildProc
{
    class CoreBuildServer
    {
        private XDocument doc { get; set; } = new XDocument();
        private string storagePath { get; set; } = "../../BuilderStorage";
        private string receivePath { get; set; } = "../../TestStorage";
        private List<string> files { get; set; } = new List<string>();
        private string backupPath { get; set; } = "../../TestStorage";
        bool compileResult = false;

        /*----< initialize RepoMock Storage>---------------------------*/
        CoreBuildServer()
        {
            if (!Directory.Exists(storagePath))
                Directory.CreateDirectory(storagePath);
            if (!Directory.Exists(receivePath))
                Directory.CreateDirectory(receivePath);
        }

        /*----< private helper function for RepoMock.getFiles >--------*/
        private void getFilesHelper(string path, string pattern)
        {
            string[] tempFiles = Directory.GetFiles(path, pattern);
            for (int i = 0; i < tempFiles.Length; ++i)
            {
                tempFiles[i] = Path.GetFullPath(tempFiles[i]);
            }
            files.AddRange(tempFiles);
            string[] dirs = Directory.GetDirectories(path);
            foreach (string dir in dirs)
            {
                getFilesHelper(dir, pattern);
            }
        }

        /*----< find all the files in CoreBuildServer.storagePath >-----------*/
        /*
        *  Finds all the files, matching pattern, in the entire 
        *  directory tree rooted at repo.storagePath.
        */
        private void getFiles(string pattern)
        {
            files.Clear();
            getFilesHelper(storagePath, pattern);
        }

       
        
        /*----< Parsing the Build Request in CoreBuildServer >--------*/
        string[] ParseStoreFiles(ref TestRequest tr2, ref string build_req, ref List<KeyValuePair<string,string>> file_set)
        {
            Console.WriteLine("\nParsing the Build Request in CoreBuildServer : {0}", build_req);
            string[] test_names;
            tr2.loadXml(build_req);
            tr2.parse("author");
            tr2.parse("dateTime");
            tr2.test_list.AddRange(tr2.parseTestList("test"));
            test_names = new string[tr2.test_list.Count];
            for (int i = 0; i < tr2.test_list.Count; i++)
            {
                test_names[i] = tr2.test_list[i].testName;
                file_set.Add(new KeyValuePair<string,string>(tr2.test_list[i].testName, tr2.test_list[i].testDriver));
                foreach (string file in tr2.test_list[i].testedFiles)
                { file_set.Add(new KeyValuePair<string,string>(tr2.test_list[i].testName, file)); }
            }
            Console.WriteLine("\n fileset count : {0}", file_set.Count);
            return test_names;
        }


        /*----< Create DLL Files >--------*/
        string CompileExecutable(List<string> source, string str,string testname)
        {            
            string[] sourceName = new string[source.Count];
            string myAppPath = System.Reflection.Assembly.GetEntryAssembly().Location;
            Directory.SetCurrentDirectory(myAppPath.Substring(0, myAppPath.LastIndexOf("\\")));
            for (int i = 0; i < source.Count; i++)
            {
                sourceName[i] = source[i];
                sourceName[i] = Path.GetFullPath(Path.Combine(ServiceEnvironment.fileStorage, Path.GetFileName(sourceName[i])));
            }
            FileInfo sourceFile = new FileInfo("R.vpp");
            if (sourceName.Length != 0) { sourceFile = new FileInfo(sourceName[0]); }
            CodeDomProvider provider = null;
            string dllName = "", dllPath = "";
            if (sourceFile.Extension.ToUpper(CultureInfo.InvariantCulture) == ".CS")
            { provider = CodeDomProvider.CreateProvider("CSharp"); }
            else
            { Console.WriteLine("\nSource file must have a .cs extension"); }
            if (provider != null)
            {
                CoreBuildServer cbs;
                StringBuilder logtext;
                CompilerResults cr;
                CompileDll(str, testname, sourceName, out myAppPath, provider, out dllName, out dllPath, out cbs, out logtext, out cr); string time = DateTime.Now.ToString("MM_dd_yyyy_HH_mm_ss");
                string title = "\n\n  Build Logged in: " + time;
                logtext = new StringBuilder(title);
                logtext.Append("\n " + new string('=', title.Length));
                if (cr.Errors.Count > 0)
                {
                    Console.WriteLine("\nErrors building {0} into {1}", sourceName, cr.PathToAssembly);
                    foreach (CompilerError ce in cr.Errors)
                    {
                        Console.WriteLine("  {0}", ce.ToString());
                        logtext.Append("\nError\n" + ce.ToString() + "\n");
                        compileResult = false;
                    }
                }
                else
                {
                    logtext.Append("\nSuccessful dll creation\n" + cr.PathToAssembly + "\n");
                    Console.WriteLine("\nSource {0} built into {1} successfully.", sourceName, cr.PathToAssembly);
                    compileResult = true;
                }
                string filepath = Path.Combine(cbs.storagePath, Path.GetFileNameWithoutExtension(str) + "log.txt");
                File.WriteAllText(filepath, logtext.ToString());
            }
            if (compileResult == true) return dllName;
            else return "Nodll";
        }

        //<----------------Creating Dlls------------------->
        private static void CompileDll(string str, string testname, string[] sourceName, out string myAppPath, CodeDomProvider provider, out string dllName, out string dllPath, out CoreBuildServer cbs, out StringBuilder logtext, out CompilerResults cr)
        {
            cbs = new CoreBuildServer();
            dllPath = cbs.receivePath;
            logtext = new StringBuilder();
            if (!System.IO.Directory.Exists(dllPath))
                System.IO.Directory.CreateDirectory(dllPath);
            CompilerParameters cp = new CompilerParameters();
            cp.GenerateExecutable = false;
            myAppPath = System.Reflection.Assembly.GetEntryAssembly().Location;
            Directory.SetCurrentDirectory(myAppPath.Substring(0, myAppPath.LastIndexOf("\\")));
            string mainPath = ServiceEnvironment.fileStorage;
            if (!System.IO.Directory.Exists(mainPath))
                System.IO.Directory.CreateDirectory(mainPath);
            string writePath = Path.Combine(mainPath, Path.GetFileNameWithoutExtension(str) + testname + ".dll");
            cp.OutputAssembly = writePath;
            dllName = (writePath);
            cr = provider.CompileAssemblyFromFile(cp, sourceName);
        }

        /*----< Create Message>-----------------------------------*/
        void createMsg(Comm comm, CommMessage.MessageType type, string command, string author, string file, string to, string from, List<string> list,byte[]  block)
        {
            CommMessage csndMsg = new CommMessage(type);
            csndMsg.command = command;
            csndMsg.author = author;
            csndMsg.file = file;
            csndMsg.to = to;
            csndMsg.from = from;
            if (list == null)
            {
                List<string> templist = new List<string>();
                templist.Add("nothing here");
                csndMsg.arguments = templist;
            }
            else
                csndMsg.arguments = list;
            if (block == null)
            {
                byte[] b = { 100 };

                csndMsg.block = b;
            }
            else
                csndMsg.block = block;

            comm.postMessage(csndMsg);
                csndMsg.show();
        }

        /*----< test Comm instance >-----------------------------------*/
        bool testComm(string num)
        {
            CoreBuildServer cbs = new CoreBuildServer();
            bool test = true, process_notdone = true;
            int port = 8080 + Convert.ToInt32(num);
            string toPort = "http://localhost" + ":" + port.ToString() + "/IPluggableComm";
            Console.Write("\n Child {0} Port :{1}", num, toPort);
            Comm comm = new Comm("http://localhost", port);
            string myPath = System.Reflection.Assembly.GetEntryAssembly().Location;
            Directory.SetCurrentDirectory(myPath.Substring(0, myPath.LastIndexOf("\\")));
            Console.WriteLine("\n\n The Dlls and the Build Request files can be found at : {0}\n", Path.GetFullPath("../../BuilderStorage"));
            cbs.createMsg(comm, CommMessage.MessageType.ready, "ready", toPort, "xml", "http://localhost:9090/IPluggableComm", toPort, null,null);
            CommMessage crcvMsg;
            int k = 0;
            List<string> file_set = new List<string>();
            List<KeyValuePair<string, string>> file_pair = new List<KeyValuePair<string, string>>();            
            string build_request = "";
            while (process_notdone)
            {
                crcvMsg = comm.getMessage();
                crcvMsg.show();
                if (crcvMsg.type == CommMessage.MessageType.requestXml)
                {
                    cbs.receivePath = cbs.backupPath;
                    build_request = crcvMsg.file;
                    string foldername = Path.Combine(storagePath, Path.GetFileName(crcvMsg.file));
                    cbs.createMsg(comm, CommMessage.MessageType.reply, Path.GetFullPath(foldername), toPort, crcvMsg.file, "http://localhost:8080/IPluggableComm", toPort, null,null);
                    //Thread.Sleep(200);
                }
                if (crcvMsg.type == CommMessage.MessageType.reply)
                {
                    createTestRequest(cbs, toPort, comm, ref crcvMsg, ref k, file_set, ref file_pair, build_request);
                }
                if(crcvMsg.type==CommMessage.MessageType.closeReceiver)
                {
                    Process process = Process.Start("ChildProc.exe");
                    Thread.Sleep(1000);
                    process.Kill();
                }
            }                           
            return test;
        }

        //<---------------Create Test Request--------------->
        private void createTestRequest(CoreBuildServer cbs, string toPort, Comm comm, ref CommMessage crcvMsg, ref int k, List<string> file_set, ref List<KeyValuePair<string, string>> file_pair, string build_request)
        {
            string foldername = Path.Combine(storagePath, Path.GetFileName(crcvMsg.file));
            comm.postFile( ref foldername, crcvMsg.block);
            TestRequest tr2;
            string[] test_names;
            List<string> dll_names;
            dllAndTestRequest(cbs, toPort, comm, ref crcvMsg, ref k, file_set, ref file_pair, build_request, out tr2, out test_names, out dll_names);
            foreach (string dllFile in dll_names)
            {
                string dllfilefolder = Path.Combine(TestEnvironment.fileStorage);
                if (!Directory.Exists(dllfilefolder))
                    Directory.CreateDirectory(dllfilefolder);
                string dllfilename = Path.Combine(dllfilefolder, Path.GetFileName(dllFile));
                byte[] dllblock= null;
                bool transferSuccess = comm.postFile1(dllFile, ref dllblock);
                createMsg(comm, CommMessage.MessageType.sendDll, Path.GetFileName(build_request), toPort, (dllFile), "http://localhost:9001/IPluggableComm", toPort, null,dllblock);
                TestUtilities.checkResult(transferSuccess, "transfer");
            }
            TestRequest tr3 = new TestRequest();
            tr3.makeRequest(tr2.author, test_names, dll_names);
            int last = build_request.LastIndexOf("Request");
            string namestr = build_request.Substring(last);
            //string reqname = Path.Combine(Path.Combine(cbs.storagePath,Path.GetFileNameWithoutExtension(build_request)), "Test" + namestr);
            string reqname = Path.Combine(cbs.storagePath, "Test" + namestr);
            tr3.saveXml(reqname);
            string reqfilename = Path.Combine(TestEnvironment.fileStorage, Path.GetFileName(reqname));
            byte[] reqread = null; 
            bool transferSuccess1 = comm.postFile1(reqname,ref reqread);
            createMsg(comm, CommMessage.MessageType.start, Path.GetFileName(build_request), toPort, reqfilename, "http://localhost:9001/IPluggableComm", toPort, dll_names,reqread);
            createMsg(comm, CommMessage.MessageType.ready, "ready", toPort, "xml", "http://localhost:9090/IPluggableComm", toPort, null,null);
        }

        //<---------------testrequest dll addition--------------->s
        private void dllAndTestRequest(CoreBuildServer cbs, string toPort, Comm comm, ref CommMessage crcvMsg, ref int k, List<string> file_set, ref List<KeyValuePair<string, string>> file_pair, string build_request, out TestRequest tr2, out string[] test_names, out List<string> dll_names)
        {
            string str = crcvMsg.file;
            tr2 = new TestRequest();
            file_pair.Clear();
            test_names = cbs.ParseStoreFiles(ref tr2, ref str, ref file_pair);
            dll_names = new List<string>();
            foreach (string testname in test_names)
            {
                k = 0;
                file_set.Clear();
                for (int r = 0; r < file_pair.Count; r++)
                {
                    if (file_pair[r].Key.Equals(testname, StringComparison.Ordinal))
                    {
                        file_set.Add(file_pair[r].Value);
                    }
                }
                foreach (string file in file_set)
                {
                    cbs.createMsg(comm, CommMessage.MessageType.request, file, toPort, file, "http://localhost:8080/IPluggableComm", toPort, null,null);
                    //Thread.Sleep(2000);
                }
                bool do_it = false;
                k = 0;
                while (do_it == false)
                {
                    Thread.Sleep(500);
                    crcvMsg = comm.getMessage();
                    if (crcvMsg.type == CommMessage.MessageType.request)
                    {
                        string filefoldername = Path.Combine((storagePath), Path.GetFileName(crcvMsg.file));
                        comm.postFile(ref filefoldername, crcvMsg.block);
                        crcvMsg.show();
                        k++;
                    }
                    if (k == file_set.Count)
                    {
                        dll_names.Add(cbs.CompileExecutable(file_set, Path.GetFileName(build_request), testname));
                        //cbs.createMsg(comm, CommMessage.MessageType.requestXml, "send", toPort, Path.GetFileName(build_request), crcvMsg.from, toPort, null);
                        string logfile = Path.Combine(cbs.storagePath, Path.GetFileNameWithoutExtension(str) + "log.txt");
                        byte[] logread = null;
                        comm.postFile1(logfile, ref logread);
                        cbs.createMsg(comm, CommMessage.MessageType.sendLog, "send", toPort, logfile, "http://localhost:8080/IPluggableComm", toPort, null,logread);
                        do_it = true;
                    }
                }
            }
        }


        static void Main(string[] args)
        {
            Console.Title = "Process Pool Child Builder";
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            CoreBuildServer cbs = new CoreBuildServer();
            if (args.Count() == 0)
            {
                Console.Write("\n  please enter integer value on command line");
                return;
            }
            else
            {
                Console.Write("\n  Hello from child #{0}\n\n", args[0]);
            }

            ClientEnvironment.verbose = true;
            TestUtilities.checkResult(cbs.testComm(args[0]), "Comm");
            TestUtilities.putLine();
            TestUtilities.putLine("Press key to quit\n");
            if (ClientEnvironment.verbose)
                Console.ReadKey();

        }
    }
}
