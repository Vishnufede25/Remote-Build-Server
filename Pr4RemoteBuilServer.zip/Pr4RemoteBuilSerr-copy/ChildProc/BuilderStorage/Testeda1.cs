﻿/////////////////////////////////////////////////////////////////////
// Tested1.cs - demonstration production code                      //
//                                                                 //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017 //
/////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace TestBuild
{
  public class Tested1a
    {
    public int Bodmas(int a, int b,int c)
    {
            return a * (b + c);
    }
  }
}
