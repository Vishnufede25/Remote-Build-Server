﻿/////////////////////////////////////////////////////////////////////
// Tested2.cs - demonstration production code                      //
//                                                                 //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017 //
/////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;


namespace TestBuild
{
    public class Tested2a 
    {
        public int array_add(int[] arr,int count)
        {
            if (arr.Length < count)
                throw new IndexOutOfRangeException();
            int sum = 0;
            for (int i = 0; i < count; i++)
            {
                    sum += arr[i];
            }

            return sum;
        }
    }
}