﻿///////////////////////////////////////////////////////////////////////////
// CoreBuildServer.cs - It is Responsible to carry out build process     //
//                      processing the build request and creating DLLs   //
// Platform:    MSI , Windows 10, Visual Studio 2017                     //
// Author:      Vishnu Prasad Vishwanathan                               //
// Referenece:  Jim Fawcett                                              //
// SUID:        793782749                                                //
//             (315)382-9922,                                            //
//              vvishwan@syr.edu                                         //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017       //
///////////////////////////////////////////////////////////////////////////
/*
 *Prime Functions are to:
 * 
 * 1.  Parse the Buildrequest.xml
 * 2.  Create DLL for every Test in the Build Request.
 * 3.  Generate Build Logs.
 * 4.  Create the Test Request.
 * 5.  On successful build, send the Test Request to the folder Known to Test Harness.
 */

using System;
using System.IO;
using System.Globalization;
using System.CodeDom.Compiler;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Text;


namespace Federation
{
    public class CoreBuildServer
    {
        XDocument doc { get; set; } = new XDocument();
        string storagePath { get; set; } = "../../../CoreBuildServer/BuilderStorage";
        string receivePath { get; set; } = "../../../TestHarnessMock/TestStorage";
        List<string> files { get; set; } = new List<string>();
        string backupPath { get; set; } = "../../../TestHarnessMock/TestStorage";
        bool compileResult = false;
   

        /*----< initialize RepoMock Storage>---------------------------*/
        public CoreBuildServer()
        {
            if (!Directory.Exists(storagePath))
                Directory.CreateDirectory(storagePath);
            if (!Directory.Exists(receivePath))
                Directory.CreateDirectory(receivePath);
        }

        /*----< function for build logging >--------*/
        public void initiate(ref List<string> buildLogs)
        {
           buildLogs= create_DLL(); 
        }

        /*----< private helper function for RepoMock.getFiles >--------*/
        private void getFilesHelper(string path, string pattern)
        {
            string[] tempFiles = Directory.GetFiles(path, pattern);
            for (int i = 0; i < tempFiles.Length; ++i)
            {
                tempFiles[i] = Path.GetFullPath(tempFiles[i]);
            }
            files.AddRange(tempFiles);
            string[] dirs = Directory.GetDirectories(path);
            foreach (string dir in dirs)
            {
                getFilesHelper(dir, pattern);
            }
        }

        /*----< find all the files in CoreBuildServer.storagePath >-----------*/
        /*
        *  Finds all the files, matching pattern, in the entire 
        *  directory tree rooted at repo.storagePath.
        */
        public void getFiles(string pattern)
        {
            files.Clear();
            getFilesHelper(storagePath, pattern);
        }

        /*---< copy file to RepoMock.receivePath >---------------------*/
        /*
        *  Will overwrite file if it exists. 
        */
        private bool sendFile(string fileSpec)
        {
            try
            {
                string fileName = Path.GetFileName(fileSpec);
                string destSpec = Path.Combine(receivePath, fileName);
                File.Copy(fileSpec, destSpec, true);
                return true;
            }
            catch (Exception ex)
            {
                Console.Write("\n--{0}--", ex.Message);
                return false;
            }
        }

        /*----< create DLL from buldrequest.xml >--------*/
        static List<string> create_DLL()
        {   CoreBuildServer cbs = new CoreBuildServer();
            cbs.files.RemoveRange(0, cbs.files.Count);
            cbs.getFiles("BuildRequest*.xml");
            List<string> logfiles = new List<string>();
            List<string> request_files = new List<string>();
            request_files.AddRange(cbs.files);
            string savePath = cbs.receivePath;
            List<string> file_set = new List<string>();
            logfiles.RemoveRange(0, logfiles.Count);
            foreach (string build_req in request_files)
            {   Console.WriteLine("\nCore Build Server started for Build Request : {0}\n---------------------------\n", build_req);
                cbs.receivePath = cbs.backupPath;
                string just_Path = Path.GetDirectoryName(build_req);
                string main_Path = just_Path.Substring(just_Path.LastIndexOf("\\") + 1);
                if (!System.IO.Directory.Exists(savePath)) { System.IO.Directory.CreateDirectory(savePath); }                    
                string fileSpec = System.IO.Path.Combine(savePath, build_req);
                fileSpec = System.IO.Path.GetFullPath(fileSpec);
                string result = Path.GetFileNameWithoutExtension(fileSpec);
                string build_request = build_req;
                TestRequest tr2 = new TestRequest();
                string[] test_names = ParseStoreFiles(ref tr2,ref fileSpec, ref main_Path, ref build_request, ref file_set);
                string extension = "",str="";
                int num_str = 0, j = 0;
                for (int i = 0; i < file_set.Count; i++)
                { if (extension != ".xml") { num_str += 1; }}
                String[] arr2 = new string[num_str];
                List<string> dll_names = new List<string>();
                for (int i = 0; i < test_names.Length; i++)
                {   j = 0;
                    Array.Clear(arr2, 0,arr2.Length);
                    str = test_names[i];
                    for (int k = 0; k < file_set.Count; k++)
                    {   extension = "";  extension = Path.GetExtension(file_set[k]);
                        string just_Path1 = Path.GetDirectoryName(file_set[k]);
                        string main_Path1 = just_Path1.Substring(just_Path1.LastIndexOf("\\") + 1);
                        if ((extension == ".cs")) { 
                            if (main_Path1.Equals(str, StringComparison.Ordinal))
                            {  arr2[j] = file_set[k];
                                j++; } } }
                     Array.Resize(ref arr2, j);
                    cbs.compileResult = false;
                    dll_names.Add(CompileExecutable(arr2, ref cbs.compileResult, ref logfiles,test_names[i]));}
                TestRequest tr3 = new TestRequest();
                tr3.makeRequest(tr2.author, test_names, dll_names);
                int last = result.LastIndexOf("Request");
                string joinString = result.Substring(last);
                tr3.saveXml(Path.Combine(cbs.backupPath, "Test" + joinString + ".xml"));
                Console.WriteLine("\nThe Test Request : {0}\n\n", Path.GetFullPath(Path.Combine(cbs.backupPath, "Test" + joinString + ".xml")));
            } return logfiles;}


        /*----< Parsing the Build Request in CoreBuildServer >--------*/
        static string[] ParseStoreFiles(ref TestRequest tr2,ref string fileSpec, ref string main_Path, ref string build_req,ref List<string> file_set)
        {   Console.WriteLine("\nParsing the Build Request in CoreBuildServer : {0}", build_req);
            string[] test_names;
            CoreBuildServer cbs = new CoreBuildServer();
            tr2.loadXml(fileSpec);
            tr2.parse("author");
            tr2.parse("dateTime");
            tr2.test_list.AddRange(tr2.parseTestList("test"));
            string new_path = "";
            if (main_Path != "BuilderStorage")
            { new_path = System.IO.Path.Combine(cbs.receivePath, main_Path); }
            else
                new_path = cbs.receivePath;
            if (!System.IO.Directory.Exists(new_path))
                System.IO.Directory.CreateDirectory(new_path);
            cbs.receivePath = new_path;
            cbs.sendFile(build_req);
            file_set.Add(build_req);
            test_names = new string[tr2.test_list.Count];
            for (int i = 0; i < tr2.test_list.Count; i++)
            {
                test_names[i] = tr2.test_list[i].testName;
                file_set.Add(tr2.test_list[i].testDriver);
                foreach (string file in tr2.test_list[i].testedFiles)
                { file_set.Add(file); }
            }
            List<string> temp_files = new List<string>();
            cbs.getFiles("*.*");
            temp_files.AddRange(cbs.files);
            for (int i = 0; i < file_set.Count; i++)
            {
                foreach (string temp2 in temp_files)
                {
                    string just_Filename = Path.GetFileName(temp2);
                    if (file_set[i] == just_Filename)
                    {
                        file_set[i] = temp2;
                        break;
                    }
                }
            }
            return test_names;
        }
    

    /*----< Create DLL Files >--------*/
        static string CompileExecutable(String[] sourceName, ref bool compileResult, ref List<string> logfiles, string test_name)
        {   FileInfo sourceFile = new FileInfo("R.vpp");
            if (sourceName.Length != 0) { sourceFile = new FileInfo(sourceName[0]); }
            CodeDomProvider provider = null;
            string dllName = "", dllPath = "";
            if (sourceFile.Extension.ToUpper(CultureInfo.InvariantCulture) == ".CS")
            {   provider = CodeDomProvider.CreateProvider("CSharp");  }
            else if (sourceFile.Extension.ToUpper(CultureInfo.InvariantCulture) == ".VB")
            {   provider = CodeDomProvider.CreateProvider("VisualBasic");  }
            else
            {  Console.WriteLine("\nSource file must have a .cs or .vb extension");  }
            if (provider != null)
            {   CoreBuildServer cbs = new CoreBuildServer();
                dllPath = Path.Combine(cbs.receivePath, test_name);
                if (!System.IO.Directory.Exists(dllPath))
                    System.IO.Directory.CreateDirectory(dllPath);
                String fullDllName = String.Format(@"{0}\{1}.dll", Path.Combine(cbs.receivePath, test_name), test_name);
                CompilerParameters cp = new CompilerParameters();
                cp.GenerateExecutable = false;
                cp.OutputAssembly = fullDllName;
                dllName = Path.GetFileName(fullDllName);
                Console.WriteLine("\nCreating DLL for test :{0} \nDLL file name :{1}", Path.GetDirectoryName(sourceName[0]), dllName);
                CompilerResults cr;
                 cr = provider.CompileAssemblyFromFile(cp, sourceName);
                StringBuilder logtext = new StringBuilder();
                string time = DateTime.Now.ToString("MM_dd_yyyy_HH_mm_ss"), title = "\n\n  Build Log: " + time;
                logtext = new StringBuilder(title);
                logtext.Append("\n " + new string('=', title.Length));
                if (cr.Errors.Count > 0)
                { Console.WriteLine("\nErrors building {0} into {1}", sourceName, cr.PathToAssembly);
                    foreach (CompilerError ce in cr.Errors)
                    { Console.WriteLine("  {0}", ce.ToString());
                      logtext.Append("\nError\n" + ce.ToString() + "\n"); }
                      compileResult = false;}
                else
                { Console.WriteLine("\nSource {0} built into {1} successfully.", sourceName, cr.PathToAssembly);
                    logtext.Append("\nSuccessful\n" + cr.PathToAssembly + "\n");
                    compileResult = true;}
                string filepath = Path.Combine(Path.Combine(cbs.storagePath, test_name), string.Concat(string.Concat(string.Concat(string.Concat("BuildLogof_", test_name), "_"), time), ".txt"));
                System.IO.File.WriteAllText(filepath, logtext.ToString());
                logfiles.Add(filepath);                  
            }if (compileResult == true) return dllName; else return "Nodll";
            }


        /*----< Sending Build Logs >--------*/
        public void sendResults(ref List<string> Blog)
        {
            Console.Write("\n******************************************************************************************************\n");
            Console.WriteLine("\nTransferring the Build log files to Mock Repository's Folder");
            CoreBuildServer cbs = new CoreBuildServer();
            cbs.getFiles("*.txt");
            string mockrepoPath = "../../../RepoMock/RepoStorage";
            foreach (string logfile in Blog)
            {
                string rel = Path.GetDirectoryName(logfile);
                string main_Path = rel.Substring(rel.LastIndexOf("\\") + 1);
                string final_Logfile = Path.GetFileName(logfile);
                string repo_Logfile1 = Path.Combine(mockrepoPath, main_Path);
                if (!System.IO.Directory.Exists(repo_Logfile1))
                    System.IO.Directory.CreateDirectory(repo_Logfile1);
                cbs.receivePath = repo_Logfile1;
                cbs.sendFile(logfile);
                Console.WriteLine("\n File : {0} is sent to {1}", logfile, cbs.receivePath);
            }
            cbs.receivePath = cbs.backupPath;
            Console.WriteLine("\n Required build log files are copied from CoreBuildServer {0}", Path.GetFullPath(cbs.storagePath));
            Console.WriteLine("\n to the Mock Repository folder {0}", Path.GetFullPath(mockrepoPath));
            Console.Write("\n******************************************************************************************************\n");
        }
    }

#if (TEST_COREBUILDSERVER)

  ///////////////////////////////////////////////////////////////////
  // TestRepoMock class

  class CoreBuildServer
  {
    static void Main(string[] args)
    {
      Console.Write("\n  Demonstration of CoreBuildServer");
      Console.Write("\n ============================");

      CoreBuildServer cbs = new CoreBuildServer();
      List<string> buildLogs = new List<string>();
      cbs.initiate(ref buildLogs);          
      cbs.sendResults(ref buildLogs);
      Console.Write("\n\n");
            Console.ReadLine();
    }
  }
#endif

}




