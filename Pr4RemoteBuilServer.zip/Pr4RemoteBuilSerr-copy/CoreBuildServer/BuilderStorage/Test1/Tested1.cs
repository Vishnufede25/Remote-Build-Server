﻿/////////////////////////////////////////////////////////////////////
// Tested1.cs - demonstration production code                      //
//                                                                 //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017 //
/////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace TestBuild
{
  public class Tested1
    {
    public int addition(int a, int b)
    {
            return a + b;
    }
  }
}
