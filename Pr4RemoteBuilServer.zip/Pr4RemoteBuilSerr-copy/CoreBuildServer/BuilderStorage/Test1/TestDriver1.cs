﻿/////////////////////////////////////////////////////////////////////
// TestDriver.cs - demonstration test driver                       //
//                                                                 //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017 //
/////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TestBuild
{
    interface ITest
    {
        bool test();
    }

    public class TestDriver1 : ITest
    {
        StringBuilder logtext = new StringBuilder();
    bool testTested1()
    {
      bool result = true;
      Tested1 td1 = new Tested1();
      int first_num = 10, second_num = 15;
      string curr_path = Path.GetFullPath("../../../TestHarnessMock/TestStorage/test1");
      logtext.Append("\nTestFile:"+ curr_path);

      Console.WriteLine("\n");
      Console.WriteLine("Processing:" + curr_path + "/Tested1.cs\n\n");
      Console.WriteLine("\nAddition of two numbers");
      Console.WriteLine("Inputs : first number = {0} , Second number = {1}", first_num, second_num);
      logtext.Append("\nDescription: Addition of two numbers");
      logtext.Append("\nTest input1:".ToString()+ first_num.ToString());
      logtext.Append(("\nTest input2:"+ second_num.ToString()));

      int value = td1.addition(first_num,second_num);
      logtext.Append(("\nAdditionResult:"+ value.ToString()));
      if (value != 25)
      {
         result = false;                
      }
    logtext.Append(("\nTestResult:"+ result.ToString()));
    Console.WriteLine("\nTested1.cs is processed and logs are added to the file test1log.txt");
    Console.WriteLine("\nResult of Tested1 : " + result);
            return result;
    }

    bool testTested2()
    {
      bool result = true;
      Tested2 td2 = new Tested2();
      string curr_path = Path.GetFullPath("../../../TestHarnessMock/TestStorage/test1");
      Console.WriteLine("\n");
      Console.WriteLine("Processing:" + curr_path+"/Tested2.cs\n\n");
      logtext.Append("\nTestFile:"+ curr_path);
      logtext.Append("\nTested2Input:"+ 5.ToString());
      logtext.Append("\nTested2Desc:"+ "sum of first 5 integers".ToString());
      Console.WriteLine("Inputs : Number of integers to add : 5");
      int[] arr = { 1, 1, 2, 3, 4, 4 };
      int value = 0;
      try
      {
          value  = td2.array_add(arr,5);         
      }
      catch (IndexOutOfRangeException e)
      {
                Console.WriteLine("Index out of range exception : {0}", e.Message);
                logtext.Append("\nerror:"+ e.Message.ToString());
      }
      catch (Exception e)
      {
                Console.WriteLine("Array Exception : {0}", e.Message);
                logtext.Append("\nerror:"+ e.Message.ToString());
      }
      logtext.Append("\ntested2Sum:"+ value.ToString());
      logtext.Append("\ntested2ExpectedSum:"+ "11".ToString());
      if (value != 11)
          result = false;
            logtext.Append("\ntestResult:"+ result.ToString());
      Console.WriteLine("\nTested2.cs is processed and logs are added to the file test1log");
      Console.WriteLine("\nResult of Tested2 : "+ result);
      string time = DateTime.Now.ToString("MM_dd_yyyy_HH_mm_ss");
      string fullName = "../../../TestHarnessMock/TestStorage/test1/test1log" + time + ".txt";
      System.IO.File.WriteAllText(fullName, logtext.ToString());
      Console.WriteLine("\nTested1.cs and Tested2.cs is processed and logs are added to the file test1log.txt");
      return result;
    }
    public bool test()
    {
      StringBuilder logtext = new StringBuilder();
      logtext.Append("\nTest Log file");
      logtext.Append("\ntestDriver".ToString()+ "testDriver1".ToString());
      bool result1 = testTested1();
      bool result2 = testTested2();
      string currentFile = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileName();
      logtext.Append("\nFinal_result"+ (result1 && result2).ToString());
      Console.WriteLine("\n\nThe logs can be found in {0}",Path.GetFullPath("../../../TestHarnessMock/TestStorage/test1"));  
      return result1 && result2;
    }
    static void Main(string[] args)
    {
      TestDriver1 tr1 = new TestDriver1();
      if (tr1.test())
         Console.Write("\nOverall Test passed");
      else
         Console.Write("\nOverall Test failed");
      Console.Write("\n\n");
      Console.ReadLine();
    }
    }
}
