﻿/////////////////////////////////////////////////////////////////////
// TestDriver.cs - demonstration test driver                       //
//                                                                 //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017 //
/////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TestBuild
{
    interface ITest
    {
        bool test();
    }

    public class TestDriver1a : ITest
    {
        StringBuilder logtext = new StringBuilder();
    bool testTested1()
    {
      bool result = true;
      Tested1a td1 = new Tested1a();
      int first_num = 10, second_num = 5 , third_num = 5;
      string curr_path = Path.GetFullPath("../../../TestHarnessMock/TestStorage/test2");
      logtext.Append("\nTestFile:"+ curr_path);

      Console.WriteLine("\n");
      Console.WriteLine("Processing:" + curr_path + "/Testeda1.cs\n\n");
      Console.WriteLine("\nBodmas check with 3 numbers");
      Console.WriteLine("\nInputs : first number = {0} , Second number = {1} , third number = {2}", first_num, second_num,third_num);
      logtext.Append("\nDescription: Bodmas check with 3 numbers");
      logtext.Append("\nTest input1:".ToString()+ first_num.ToString());
      logtext.Append(("\nTest input2:"+ second_num.ToString()));
      logtext.Append(("\nTest input3:" + third_num.ToString()));
      int value = td1.Bodmas(first_num,second_num,third_num);
      logtext.Append(("\nBodmasResult:"+ value.ToString()));
      if (value != 100)
      {
         result = false;                
      }
	 Console.WriteLine("\nResult of Testeda1 : "+ result);
    logtext.Append(("\nTestResult:"+ result.ToString()));
            return result;
    }

    bool testTested2()
    {
      bool result = true;
      Tested2a td2 = new Tested2a();
      string curr_path = Path.GetFullPath("../../../TestHarnessMock/TestStorage/test2");
      Console.WriteLine("\n");
      Console.WriteLine("Processing:" + curr_path + "/Testeda2.cs\n\n");
      logtext.Append("\nTestFile:"+ curr_path);
      logtext.Append("\nTested2aInput:"+ 9.ToString());
      logtext.Append("\nTested2aDesc:"+ "sum of first 5 integers".ToString());
      Console.WriteLine("\nInputs : Number of integers to add : 5");
      int[] arr = { 1, 1, 2, 3, 4, 4 };
      int value = 0;
      try
      {
          value  = td2.array_add(arr,5);         
      }
      catch (IndexOutOfRangeException e)
      {
                Console.WriteLine("Index out of range exception : {0}", e.Message);
                logtext.Append("\nerror:"+ e.Message.ToString());
      }
      catch (Exception e)
      {
                Console.WriteLine("Array Exception : {0}", e.Message);
                logtext.Append("\nerror:"+ e.Message.ToString());
      }
      logtext.Append("\ntested2aSum:"+ value.ToString());
      logtext.Append("\ntested2ExpectedSum:"+ "11".ToString());
      if (value != 17)
          result = false;
            logtext.Append("\ntestResult:"+ result.ToString());
      Console.WriteLine("\nResult of Testeda2 : "+ result);
            string time = DateTime.Now.ToString("MM_dd_yyyy_HH_mm_ss");
            string fullName = "../../../TestHarnessMock/TestStorage/test2/test2log" + time+".txt";
            System.IO.File.WriteAllText(fullName, logtext.ToString());
            Console.WriteLine("\nTesteda1.cs and Testeda2.cs are processed and logs are added to the file test2log.txt");
            return result;
    }
    public bool test()
    {
      StringBuilder logtext = new StringBuilder();
      logtext.Append("\nTest Log file");
      logtext.Append("\ntestDriver".ToString()+ "testDriver1a".ToString());
      bool result1 = testTested1();
      bool result2 = testTested2();
      string currentFile = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileName();
      logtext.Append("\nFinal_result"+ (result1 && result2).ToString());
      Console.WriteLine("\n\nThe logs can be found in {0}",Path.GetFullPath("../../../TestHarnessMock/TestStorage/test2"));  
      return result1 && result2;
    }
    static void Main(string[] args)
    {
      TestDriver1a tr1 = new TestDriver1a();
      if (tr1.test())
         Console.Write("\nOverall Test passed");
      else
         Console.Write("\nOverall Test failed");
      Console.Write("\n\n");
      Console.ReadLine();
    }
    }
}
