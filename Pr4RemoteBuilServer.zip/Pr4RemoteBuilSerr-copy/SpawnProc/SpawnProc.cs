﻿////////////////////////////////////////////////////////////////////////
// SpawnProc.cs - Process Pool Child Builder                                       //
// Platform:    MSI , Windows 10, Visual Studio 2017                  //
// Author:      Vishnu Prasad Vishwanathan                            //
// Referenece:  Jim Fawcett                                           //
// SUID:        793782749                                             //
//             (315)382-9922,                                         //
//              vvishwan@syr.edu                                      //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017    //
////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * The primary functions of SpawnProc are:
 * 1. If it is a batch file run then take the default 2 child processes.
 * 2. Perform the build operation when a build request is issued by the mother builder.
 * 3. After completion send ready message and wait for the mother builder to respond.
 * 
 * Public Interface:
 * -------------------
 * This package contains a single class SpawnProc with functions:
 * - createProcess    : function for creating child process
 * 
 * Required Files:
 * ---------------
 * - IMessagePassingComm  - WCF Message Communication Interface
 * - MessagePassingComm   - WCF Message Communication Class
 * - RepoMock             - Repository for file exchange
 * - TestUtilities        - Helper class that is used mostly for testing
 *  
 * Maintenance History:
 * --------------------
 * ver 1.0 : 08 Dec 2017
 * - first release
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.ServiceModel;
using Federation;
using MessagePassingComm;

namespace SpawnProc
{
    
    class SpawnProc
    {
        //<----------------Creating Processes------------->
        static bool createProcess(int i)
        {
            Process proc = new Process();
            string fileName = "..\\..\\..\\ChildProc\\bin\\debug\\ChildProc.exe";
            string absFileSpec = Path.GetFullPath(fileName);

            Console.Write("\n  attempting to start {0}", absFileSpec);
            string commandline = i.ToString();
            try
            {
                Process.Start(fileName, commandline);
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
                return false;
            }
            return true;
        }

        static void Main(string[] args)
        {
            Console.Title = "SpawnProc";
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.Write("\n Children creation : http:////localhost:9000/IPluggableComm");
            Comm comm = new Comm("http://localhost", 9000);
            string toPort = "http://localhost" + ":" + 9000.ToString() + "/IPluggableComm";
            CommMessage crcvMsg;
            int count = 0;
            Console.WriteLine("\n\n The Dlls and the Build Request files can be found at : {0}\n", Path.GetFullPath("../../../ChildProc/BuilderStorage"));
            if (args[0] != "start"){
                while (true)
                {   crcvMsg = comm.getMessage();
                    if (crcvMsg.type == CommMessage.MessageType.connect)
                        crcvMsg.show();
                    if (crcvMsg.type == CommMessage.MessageType.start){
                        crcvMsg.show();
                        Console.WriteLine("\n Start from WPF ");
                        count = Convert.ToInt32(crcvMsg.arguments[0]);
                        for (int i = 1; i <= count; ++i){
                            if (createProcess(i))
                                Console.Write(" - succeeded");
                            else
                                Console.Write(" - failed");}
                        break;
                    }}}
            else{
                count = 3;
                Console.WriteLine("\n Start from Batch (run.bat) with default # children",count);
                for (int i = 1; i <= count; ++i){
                    if (createProcess(i))
                        Console.Write(" - succeeded");
                    else
                        Console.Write(" - failed");
                    }}           
    }} } 
