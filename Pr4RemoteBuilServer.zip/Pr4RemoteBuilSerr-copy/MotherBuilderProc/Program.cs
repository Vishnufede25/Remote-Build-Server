﻿////////////////////////////////////////////////////////////////////////
// Program.cs - Mother Builder                                        //
// Platform:    MSI , Windows 10, Visual Studio 2017                  //
// Author:      Vishnu Prasad Vishwanathan                            //
// Referenece:  Jim Fawcett                                           //
// SUID:        793782749                                             //
//             (315)382-9922,                                         //
//              vvishwan@syr.edu                                      //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017    //
////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * The primary functions of Nother Builder are:
 * 1. When RepoMock sends the Build requests, put them in a queue and send 
 *    the Build Requests to the child builders whenever they are ready
 * 2. When there are no requests to be handled then close the receivers
 * 
 * Public Interface:
 * -------------------
 * This package contains a single class MotherBuilder with functions:
 * - testComm    : Passing the created WCF Messages
 * 
 * Required Files:
 * ---------------
 * - IMessagePassingComm  - WCF Message Communication Interface
 * - MessagePassingComm   - WCF Message Communication Class
 * - TestUtilities        - Helper class that is used mostly for testing
 *  
 * Maintenance History:
 * --------------------
 * ver 1.0 : 08 Dec 2017
 * - first release
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;
using System.Threading;
//using System.ServiceModel;
//using Federation;

namespace MessagePassingComm
{
    ///////////////////////////////////////////////////////////////////
    // Receiver class - receives CommMessages and Files from Senders


    class MotherBUilder
    {
        //<----------------passing WCF messages--------------->
        void testComm()
        {
            TestUtilities.putLine("Mother Builder : http:////localhost:9090/IPluggableComm");
            string toPort = "http://localhost" + ":" + 9090.ToString() + "/IPluggableComm";
            Comm comm = new Comm("http://localhost", 9090);
            SWTools.BlockingQueue<string> requestQ = new SWTools.BlockingQueue<string>();
            SWTools.BlockingQueue<string> childQ = new SWTools.BlockingQueue<string>();
            CommMessage crcvMsg;
            List<string> ports = new List<string>();
            crcvMsg = comm.getMessage();
            while (true)
            {
                crcvMsg = comm.getMessage();
                if (crcvMsg.type == CommMessage.MessageType.connect)
                    crcvMsg.show();
                if (crcvMsg.type == CommMessage.MessageType.requestXml)
                {
                    crcvMsg.show();
                    foreach (var buildReq in crcvMsg.arguments)
                    {
                        requestQ.enQ(buildReq);
                    }
                }
                if (crcvMsg.type == CommMessage.MessageType.ready)
                {
                    crcvMsg.show();
                    childQ.enQ(crcvMsg.from);
                    bool is_there = false;
                    foreach (string port in ports)
                    {
                        if (port == crcvMsg.from)
                        {
                            is_there = true;
                            break;
                        }
                    }
                    if (is_there == false) { ports.Add(crcvMsg.from); }
                }
                if (childQ.size() != 0 && requestQ.size() != 0)
                    sendRequest(comm, requestQ, childQ);
                if(crcvMsg.type==CommMessage.MessageType.end)
                {
                    endchildren(toPort, comm, ports);
                }
                if (crcvMsg.type==CommMessage.MessageType.closeReceiver){
                    Process process = Process.Start("MotherBuilderProc.exe");
                    Thread.Sleep(1000);
                    process.Kill();
                }} }

        private static void endchildren(string toPort, Comm comm, List<string> ports)
        {
            foreach (var port in ports)
            {
                CommMessage msg3 = new CommMessage(CommMessage.MessageType.closeReceiver);
                msg3.author = toPort;
                msg3.to = port;
                msg3.from = toPort;
                comm.postMessage(msg3);

            }
        }

        //<-------------------------Sending Request----------------->
        private static void sendRequest(Comm comm, SWTools.BlockingQueue<string> requestQ, SWTools.BlockingQueue<string> childQ)
        {
            CommMessage csndMsg = new CommMessage(CommMessage.MessageType.requestXml);
            string childPort = childQ.deQ();
            csndMsg.command = "xml";
            csndMsg.author = "http://localhost:9090/IPluggableComm";
            csndMsg.file = requestQ.deQ();
            Console.WriteLine("\n The {1} is sent to {0} for processing", childPort, csndMsg.file);
            csndMsg.to = childPort;
            csndMsg.from = "http://localhost:9090/IPluggableComm";
            comm.postMessage(csndMsg);
            csndMsg.show();
        }

        /*----< do the tests >-----------------------------------------*/

        static void Main(string[] args)
        {
            MotherBUilder mb = new MotherBUilder();
            ClientEnvironment.verbose = true;
            TestUtilities.vbtitle("Mother Builder", '=');


            mb.testComm();

        }

    }
}
