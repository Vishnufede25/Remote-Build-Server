﻿/////////////////////////////////////////////////////////////////////////////
// TestHarnessMock.cs - Demonstrate Robust loading and dynamic invocation  //
//               of DLL found in specified location  and running tests     //
// Platform:    MSI , Windows 10, Visual Studio 2017                       //
// Author:      Vishnu Prasad Vishwanathan                                 //
// Referenece:  Jim Fawcett                                                //
// SUID:        793782749                                                  //
//             (315)382-9922,                                              //
//              vvishwan@syr.edu                                           //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017         //
/////////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * The Primary functions of Test Harness:
 * 1.  Parse the Test Request.
 * 2.  Run the DLL files of each test in the Test Request.
 * 3.  Create TEst logs for each test.
 * 3.  On Command from client send the test logs to the Mock Repository.  
 * 
 * Public Interface:
 * -------------------
 * This package contains a single class TestHarnessMock with functions:
 * - getFilesHelper         : function for getting files
 * - getFiles               : Finds all the files, matching pattern, in the entire directory 
 * - loadAndExerciseTesters : load assemblies from testersLocation and run their tests
 * - sendFile               : File sending function
 * - runSimulatedTest       : run tester t from assembly asm 
 * - sendResults            : send test results 
 * 
 * Required Files:
 * ---------------
 * - TesRequest- Test Request Creation
 *  
 * Maintenance History:
 * --------------------
 * ver 1.0 : 08 Dec 2017
 * - first release
 * 
 */

using System;
using System.Reflection;
using System.IO;
using System.Collections.Generic;
using MessagePassingComm;

namespace Federation
{   //Testharness Class
    public class TestHarnessMock
    {
        static string testersLocation { get; set; } = "../../TestStorage/";
        string receivePath { get; set; } = "../../TestStorage";
        List<string> files { get; set; } = new List<string>();
        string backupPath { get; set; } = "../../RepoStorage";

        public TestHarnessMock()
        {
            if (!Directory.Exists(receivePath))
                Directory.CreateDirectory(receivePath);
        }

        /*----< private helper function for RepoMock.getFiles >--------*/
        private void getFilesHelper(string path, string pattern)
        {
            string[] tempFiles = Directory.GetFiles(path, pattern);
            for (int i = 0; i < tempFiles.Length; ++i)
            {
                tempFiles[i] = Path.GetFullPath(tempFiles[i]);
            }
            files.AddRange(tempFiles);
            string[] dirs = Directory.GetDirectories(path);
            foreach (string dir in dirs)
            {
                getFilesHelper(dir, pattern);
            }
        }

        /*----< find all the files in CoreBuildServer.storagePath >-----------*/
        /*
        *  Finds all the files, matching pattern, in the entire 
        *  directory tree rooted at repo.storagePath.
        */
        private void getFiles(string pattern)
        {
            files.Clear();
            getFilesHelper(testersLocation, pattern);
        }

        

        /*----< library binding error event handler >------------------*/
        /*
         *  This function is an event handler for binding errors when
         *  loading libraries.  These occur when a loaded library has
         *  dependent libraries that are not located in the directory
         *  where the Executable is running.
         */
        static Assembly LoadFromComponentLibFolder(object sender, ResolveEventArgs args)
        {
            Console.Write("\n called binding error event handler");
            string folderPath = testersLocation;
            string assemblyPath = Path.Combine(folderPath, new AssemblyName(args.Name).Name + ".dll");
            if (!File.Exists(assemblyPath)) return null;
            Assembly assembly = Assembly.LoadFrom(assemblyPath);
            return assembly;
        }

        //----< load assemblies from testersLocation and run their tests >-----
        public string loadAndExerciseTesters(string test_request)
        {
            AppDomain currentDomain = AppDomain.CurrentDomain;
            currentDomain.AssemblyResolve += new ResolveEventHandler(LoadFromComponentLibFolder);
            try
            {
                    TestRequest tr2 = new TestRequest();
                    tr2.loadXml(Path.GetFullPath(test_request));
                    Console.Write("\nParsing the Test Request :{0} \n {1}", test_request, tr2.doc.ToString());
                    tr2.parse("author");
                    tr2.parse("dateTime");
                    List<test_dll> dlls = new List<test_dll>();
                    dlls.AddRange(tr2.parseDLLList("test"));
                    foreach(var dllstr in dlls)
                        dllstr.dllName = Path.Combine(TestEnvironment.fileStorage, Path.GetFileName(dllstr.dllName));    
                    
                    for (int i = 0; i < dlls.Count; i++)
                    {
                        if (dlls[i].dllName != "Nodll")
                        {
                            Assembly asm = Assembly.LoadFile(Path.GetFullPath(dlls[i].dllName));
                            string fileName = Path.GetFileName(dlls[i].dllName);
                            Console.WriteLine("\n\n\nTesting:\n-------------\n\nLoading {0}", fileName);
                            MethodInfo Method = asm.GetTypes()[0].GetMethod("test");
                            Type[] types = asm.GetTypes();
                            foreach (Type t in types)
                            {
                                if (t.GetInterface("TestBuild.ITest", true) != null)
                                {
                                    if (!runSimulatedTest(t, asm))
                                        Console.Write("\n  test {0} failed to run", t.ToString());
                                }
                            }
                        }
                        else Console.WriteLine("\n\n{0}'s is not created successfully", dlls[i].testName);
                    }
                
            }
            catch (Exception ex)
            { return ex.Message; }
            return "Simulated Testing completed";
        }

        //----< run tester t from assembly asm >-------------------------------
        bool runSimulatedTest(Type t, Assembly asm)
        {
            try
            {
                Console.Write(
                "\n  attempting to create instance of {0}", t.ToString()
                );
                object obj = asm.CreateInstance(t.ToString());
                // run test
                bool status = false;
                MethodInfo method = t.GetMethod("test");
                if (method != null)
                    status = (bool)method.Invoke(obj, new object[0]);
                Func<bool, string> act = (bool pass) =>
                {
                    if (pass)
                        return "passed";
                    return "failed";
                };
                Console.Write("\n  test {0}", act(status));
            }
            catch (Exception ex)
            {
                Console.Write("\n  test failed with message \"{0}\"", ex.Message);
                return false;
            }
            return true;
        }

        List<string> process_It(string ext)
        {
            files.RemoveRange(0, files.Count);
            getFiles(ext);
            return files;

        }
        //<------------Create Message------------>
        void createMsg(Comm comm, CommMessage.MessageType type, string command, string author, string file, string to, string from, List<string> list,byte[] block)
        {
            CommMessage csndMsg = new CommMessage(type);
            csndMsg.command = command;
            csndMsg.author = author;
            csndMsg.file = file;
            csndMsg.to = to;
            csndMsg.from = from;
            if (list == null)
            {
                List<string> templist = new List<string>();
                templist.Add("nothing here");
                csndMsg.arguments = templist;
            }
            else
                csndMsg.arguments = list;
            comm.postMessage(csndMsg);
            if (block == null)
            {
                byte[] b = { 100 };

                csndMsg.block = b;
            }
            else
                csndMsg.block = block;

            csndMsg.show();
        }
        //<--------------Run tset request---------->
        void RunTestRequests()
        {
            TestUtilities.putLine("\nTest Harness : http:////localhost:9001/IPluggableComm");
            Comm comm = new Comm("http://localhost", 9001);
            string toPort = "http://localhost" + ":" + 9001.ToString() + "/IPluggableComm";
            Console.WriteLine("\n\n The Dlls and the Test Request files can be found at : {0}\n", Path.GetFullPath("../../TestStorage"));
            CommMessage crcvMsg;
            List<string> dllset = new List<string>();
            bool start_process = false;
            while(start_process==false)
            {
                crcvMsg = comm.getMessage();
                crcvMsg.show();
                if(crcvMsg.type==CommMessage.MessageType.sendDll)
                {
                    string sfile = Path.Combine(TestEnvironment.fileStorage, Path.GetFileName(crcvMsg.file));
                    comm.postFile(ref sfile, crcvMsg.block);
                }
                if(crcvMsg.type==CommMessage.MessageType.start)
                {             
                    string xfile = Path.Combine(TestEnvironment.fileStorage, Path.GetFileName(crcvMsg.file));
                    comm.postFile(ref xfile, crcvMsg.block);
                    string result = loadAndExerciseTesters(xfile);
                    Console.WriteLine("\nResult for TestRequest : {0} is {1}", Path.GetFileName(xfile), result);
                }
                if (crcvMsg.type==CommMessage.MessageType.sendLog)
                {
                    string result = loadAndExerciseTesters(crcvMsg.file);
                    process_It("TestDriver*.txt");
                    foreach (string logfile in files)
                    {
                        byte[] logread = null;
                        string lfile = Path.Combine(TestEnvironment.fileStorage, Path.GetFileName(logfile));
                        bool transferSuccess = comm.postFile(ref lfile, logread);
                    }
                }
            }
        }

        //----< send test results >--------------------------------------------

        static void Main(string[] args)
        {
           TestHarnessMock loader = new TestHarnessMock();
            TestHarnessMock.testersLocation = Path.GetFullPath(TestHarnessMock.testersLocation);
            // run load and tests
            loader.RunTestRequests();
            Console.Write("\n\n");
            Console.ReadLine();

        }
    }
}
