﻿////////////////////////////////////////////////////////////////////////
// MainWIndow.xaml.cs - GUI Prototype                                 //
// Platform:    MSI , Windows 10, Visual Studio 2017                  //
// Author:      Vishnu Prasad Vishwanathan                            //
// Referenece:  Jim Fawcett                                           //
// SUID:        793782749                                             //
//             (315)382-9922,                                         //
//              vvishwan@syr.edu                                      //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017    //
////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * The primary functions of GUI are:
 * 1. Help user browse from code files of repository so as to select 
 *    them for build request creation.
 * 2. Help user browse from the existing build requests so as to select it.
 * 3. Help user send build request command to repository.
 * 4. Displaying Build Logs.
 * 5. Displaying Test Logs.
 * 6. Displaying Status Messages of complete build process.
 * 
 * Public Interface:
 * -------------------
 * This package contains a single class MainWindow with private functions:
 * - rcvThreadProc   : define processing for GUI's receive thread
 * - Window_Closed   : Finds all the files, matching pattern, in the entire directory 
 * 
 * Required Files:
 * ---------------
 * - IMessagePassingComm  - WCF Message Communication Interface
 * - MessagePassingComm   - WCF Message Communication Class
 * - TestUtilities        - Helper class that is used mostly for testing
 *  
 * Maintenance History:
 * --------------------
 * ver 1.0 : 08 Dec 2017
 * - first release
 * 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Threading;
using MessagePassingComm;

namespace Navigator
{
  public partial class MainWindow : Window
  {
    private IFileMgr fileMgr { get; set; } = null;  // note: Navigator just uses interface declarations
    Comm comm { get; set; } = null;
    Dictionary<string, Action<CommMessage>> messageDispatcher = new Dictionary<string, Action<CommMessage>>();
    Thread rcvThread = null;
    bool first_run = false;

    public MainWindow()
    {
      InitializeComponent();
      
      fileMgr = FileMgrFactory.create(FileMgrType.Local); // uses Environment
      getTopFiles();
      int port = 8090;
      string toPort = "http://localhost" + ":" + port.ToString() + "/IPluggableComm";
      comm = new Comm("http://localhost", port);
      initializeMessageDispatcher();
      rcvThread = new Thread(rcvThreadProc);
      rcvThread.Start();
    }
    //----< make Environment equivalent to ClientEnvironment >-------

   
    //----< define how to process each message command >-------------

    void initializeMessageDispatcher()
    {
      // load remoteFiles listbox with files from root
       messageDispatcher["popRepoFiles"] = (CommMessage msg) =>
      {
          RepoFiles.Items.Clear();
          Repository_Files.Items.Clear();
          foreach (string file in msg.arguments)
          {
              if (System.IO.Path.GetExtension(file).Equals(".xml", StringComparison.Ordinal))
                  RepoFiles.Items.Add(System.IO.Path.GetFileName(file));

              if (System.IO.Path.GetExtension(file).Equals(".cs", StringComparison.Ordinal))
                  Repository_Files.Items.Add(System.IO.Path.GetFileName(file));
          }
        
      };
      
      messageDispatcher["logsdisplay"] = (CommMessage msg) =>
      {
          BuildLogs.Items.Clear();
        foreach (string dir in msg.arguments)
        {
             BuildLogs.Items.Add(System.IO.Path.GetFileName(dir));
        }
      };
      
      messageDispatcher["moveIntoFolderFiles"] = (CommMessage msg) =>
      {
          RepoFiles.Items.Clear();
        foreach (string file in msg.arguments)
        {
              if(System.IO.Path.GetExtension(file) == ".xml")
              RepoFiles.Items.Add(file);
        }
      };
      // load remoteDirs listbox with dirs from folder
    }
    //----< define processing for GUI's receive thread >-------------

    void rcvThreadProc()
    {
      Console.Write("\n  starting client's receive thread");
      while(true)
      {
        CommMessage msg = comm.getMessage();
        msg.show();
        if (msg.command == null)
          continue;
         if (msg.file == "second")
                    first_run = true;
        // pass the Dispatcher's action value to the main thread for execution

        Dispatcher.Invoke(messageDispatcher[msg.command], new object[] { msg });
      }
    }
    //----< shut down comm when the main window closes >-------------

    private void Window_Closed(object sender, EventArgs e)
    {
      //comm.close();
      
      // The step below should not be nessary, but I've apparently caused a closing event to 
      // hang by manually renaming packages instead of getting Visual Studio to rename them.

      System.Diagnostics.Process.GetCurrentProcess().Kill();
    }
    //----< not currently being used >-------------------------------

    private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
    {
    }
    //----< show files and dirs in root path >-----------------------

    public void getTopFiles()
    {
      
    }
        //----< move to directory root and display files and subdirs >---

        private void sendRepoFiles_Click(object sender, RoutedEventArgs e)
        {
            CommMessage msg1 = new CommMessage(CommMessage.MessageType.start);
            msg1.from = "http://localhost:8090/IPluggableComm";
            msg1.to = "http://localhost:8080/IPluggableComm";
            msg1.author = "http://localhost:8090/IPluggableComm";
            msg1.command = "start";
            foreach (var item in RepoFiles.SelectedItems)
                msg1.arguments.Add(item.ToString());
            comm.postMessage(msg1);
            if (first_run == false)
            {
                CommMessage msg2 = new CommMessage(CommMessage.MessageType.start);
                msg2.to = "http://localhost:9000/IPluggableComm";
                msg2.arguments.Clear();
                msg2.arguments.Add("3");
                comm.postMessage(msg2);
                first_run = true;
            }
        }
    //----< show selected file in code popup window >----------------

    private void Repo_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
     
    }
    //----< move to parent directory and show files and subdirs >----

    private void localUp_Click(object sender, RoutedEventArgs e)
    {
    }
    //----< move into subdir and show files and subdirs >------------

    private void localDirs_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
     
    }
    //----< move to root of remote directories >---------------------
    /*
     * - sends a message to server to get files from root
     * - recv thread will create an Action<CommMessage> for the UI thread
     *   to invoke to load the remoteFiles listbox
     */
    private void RemoteTop_Click(object sender, RoutedEventArgs e)
    {
      
    }
    //----< download file and display source in popup window >-------

    private void remoteFiles_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      // coming soon

    }
    //----< move to parent directory of current remote path >--------

    private void RemoteUp_Click(object sender, RoutedEventArgs e)
    {
      // coming soon
    }
    //----< move into remote subdir and display files and subdirs >--
    /*
     * - sends messages to server to get files and dirs from folder
     * - recv thread will create Action<CommMessage>s for the UI thread
     *   to invoke to load the remoteFiles and remoteDirs listboxs
     */
    private void remoteDirs_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      
    }

        private void BuildLogs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void showbuild_Click(object sender, RoutedEventArgs e)
        {
            CommMessage msg3 = new CommMessage(CommMessage.MessageType.displayLog);
            msg3.from = "http://localhost:8090/IPluggableComm";
            msg3.to = "http://localhost:8080/IPluggableComm";
            msg3.author = "http://localhost:8090/IPluggableComm";
            msg3.command = "getBuildFiles";
            msg3.arguments.Add(remoteDirs.SelectedValue as string);
            comm.postMessage(msg3);

        }

        private void Buildlog_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void Kill_Click(object sender, RoutedEventArgs e)
        {
            /*CommMessage msg1 = new CommMessage(CommMessage.MessageType.end);
            msg1.from = "http://localhost:8090/IPluggableComm";
            msg1.to = "http://localhost:9090/IPluggableComm";
            msg1.author = "http://localhost:8090/IPluggableComm";
            msg1.command = "End";
            msg1.arguments.Add(0.ToString());
            comm.postMessage(msg1);
            msg1 = new CommMessage(CommMessage.MessageType.closeReceiver);
            msg1.from = "http://localhost:8090/IPluggableComm";
            msg1.to = "http://localhost:9090/IPluggableComm";
            msg1.author = "http://localhost:8090/IPluggableComm";
            msg1.command = "End";
                msg1.arguments.Add(0.ToString());
            comm.postMessage(msg1);*/
        }
    }
}
