﻿////////////////////////////////////////////////////////////////////////////////////
// TestExecutive.cs -Prime Executive to run all the other Modules of the Project  //
// Platform:    MSI , Windows 10, Visual Studio 2017                              //
// Author:      Vishnu Prasad Vishwanathan                                        //
// Referenece:  Jim Fawcett                                                       //
// SUID:        793782749                                                         //
//             (315)382-9922,                                                     //
//              vvishwan@syr.edu                                                  //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017                //
////////////////////////////////////////////////////////////////////////////////////
/*
 *
 * In Project 2, the Mock Client acts as the Test Executive which creates the instances 
 * initiates the processes.
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Federation
{
    class ClientMock
    {
        static void Main(string[] args)
        {
            /*RepoMock repo = new RepoMock();
            Console.WriteLine("The Mock Repository is initiated by the Mock Client");
            Console.Write("\n******************************************************************************************************\n");
            repo.process_It();
            CoreBuildServer cbs = new CoreBuildServer();
            List<string> buildLogs = new List<string>();
            cbs.initiate(ref buildLogs);          
            cbs.sendResults(ref buildLogs);
            TestHarnessMock thm = new TestHarnessMock();
            string result = thm.loadAndExerciseTesters();
            thm.sendResults();
            Console.ReadLine();*/
        }
    }
}
