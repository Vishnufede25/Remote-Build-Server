﻿////////////////////////////////////////////////////////////////////////
// RepoMock.cs - Demonstrate a few mock repo operations               //
// Platform:    MSI , Windows 10, Visual Studio 2017                  //
// Author:      Vishnu Prasad Vishwanathan                            //
// Referenece:  Jim Fawcett                                           //
// SUID:        793782749                                             //
//             (315)382-9922,                                         //
//              vvishwan@syr.edu                                      //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017    //
////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * 1. Create the Build request on command from GUI
 * 2. Send the build requset to mother builder
 * 3. send the files requested by child builders
 * 4. Store the build logs sent by child builders
 * 5. Store the test logs sent by test harness
 * 
 * Public Interface:
 * -------------------
 * This package contains a single class RepoMock with functions:
 * - getFilesHelper    : function for getting files
 * - getFiles          : Finds all the files, matching pattern, in the entire directory 
 * - process_It        : processing build request 
 * - createMsg         : Creating WCF Send and Receive messages
 * - testComm          : Passing the created WCF Messages
 * 
 * Required Files:
 * ---------------
 * - IMessagePassingComm  - WCF Message Communication Interface
 * - MessagePassingComm   - WCF Message Communication Class
 * - TesRequest           - Test Request Creation
 * - TestUtilities        - Helper class that is used mostly for testing
 *  
 * Maintenance History:
 * --------------------
 * ver 1.0 : 08 Dec 2017
 * - first release
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using MessagePassingComm;
using System.ServiceModel;

namespace Federation
{
    ///////////////////////////////////////////////////////////////////
    // RepoMock class
    // - begins to simulate basic Repo operations

    class RepoMock
    {
        public string storagePath { get; set; } = "../../RepoStorage";
        List<string> files { get; set; } = new List<string>();
        
        /*----< initialize RepoMock Storage>---------------------------*/
        RepoMock()
        {
            if (!Directory.Exists(storagePath))
                Directory.CreateDirectory(storagePath);
        }

        /*----< private helper function for RepoMock.getFiles >--------*/
        private void getFilesHelper(string path, string pattern)
        {
            string[] tempFiles = Directory.GetFiles(path, pattern);
            for (int i = 0; i < tempFiles.Length; ++i)
            {
                tempFiles[i] = Path.GetFullPath(tempFiles[i]);
            }
            files.AddRange(tempFiles);
            string[] dirs = Directory.GetDirectories(path);
            foreach (string dir in dirs)
            {
                getFilesHelper(dir, pattern);
            }
        }

        /*----< find all the files in RepoMock.storagePath >-----------*/
        /*
        *  Finds all the files, matching pattern, in the entire 
        *  directory tree rooted at repo.storagePath.
        */
        private void getFiles(string pattern)
        {
            files.Clear();
            getFilesHelper(storagePath, pattern);
        }

        /*---< copy file to RepoMock.receivePath >---------------------*/
        /*
        *  Will overwrite file if it exists. 
        */
        

        //----< processing build request >--------------------------------------------
        List<string> process_It(string ext)
        {
            RepoMock repo = new RepoMock();
            repo.files.RemoveRange(0, repo.files.Count());
            repo.getFiles(ext);
            return repo.files;

        }

        //----< Transfering the files to CoreBuildServer >--------------------------------------------

        /*----< test Comm instance >-----------------------------------*/
        void createMsg(Comm comm, CommMessage.MessageType type, string command, string author, string file, string to, string from, List<string> list,byte[] block)
        {
            CommMessage csndMsg = new CommMessage(type);
            csndMsg.command = command;
            csndMsg.author = author;
            csndMsg.file = file;
            csndMsg.to = to;
            csndMsg.from = from;
            if (list == null)
            {
                List<string> templist = new List<string>();
                templist.Add("nothing here");
                csndMsg.arguments = templist;
            }
            else
                csndMsg.arguments = list;
            if (block == null)
            {
                byte[] b = { 100 };

                csndMsg.block = b;
            }
            else
                csndMsg.block = block;

            comm.postMessage(csndMsg);
            csndMsg.show();
        }
        bool testComm(string arg)
        {
            TestUtilities.vbtitle("Repository");
            bool test = true;
            Comm comm = new Comm("http://localhost", 8080);
            CommMessage crcvMsg;
            List<string> file_set = new List<string>();
            file_set = process_It("*.xml");
            if (arg == "start")
            {
                createMsg(comm, CommMessage.MessageType.requestXml, "send", "http://localhost:8080/IPluggableComm", "xml files", "http://localhost:9090/IPluggableComm", "http://localhost:8080/IPluggableComm", file_set, null);
                //createMsg(comm, CommMessage.MessageType.start, "popRepoFiles", "http://localhost:8080/IPluggableComm", "second", "http://localhost:8090/IPluggableComm", "http://localhost:8080/IPluggableComm", file_set, null);
                TestUtilities.putLine(string.Format("Transferring Build Request files from repository to Mother Builder process"));
            }
            else
            {
                List<string> file_set1 = new List<string>();
                file_set1 = process_It("*.*");
                createMsg(comm, CommMessage.MessageType.start, "popRepoFiles", "http://localhost:8080/IPluggableComm", "xml files", "http://localhost:8090/IPluggableComm", "http://localhost:8080/IPluggableComm", file_set1, null);
                Thread.Sleep(500);
            }
            bool do_it = true;
            crcvMsg = StartRepoProcess(comm, do_it);
            return test;
        }

        private CommMessage StartRepoProcess(Comm comm, bool do_it)
        {
            List<string> file_set = new List<string>();
            file_set = process_It("*.xml");
            CommMessage crcvMsg = null ;
            while (do_it)
            {
                crcvMsg = comm.getMessage();
                if (crcvMsg.type == CommMessage.MessageType.start)
                    createMsg(comm, CommMessage.MessageType.requestXml, "send", "http://localhost:8080/IPluggableComm", "xml files", "http://localhost:9090/IPluggableComm", "http://localhost:8080/IPluggableComm", crcvMsg.arguments, null);
                if (crcvMsg.type == CommMessage.MessageType.reply)
                {
                    string brfile = Path.Combine(storagePath, crcvMsg.file);
                    byte[] xmlread = null;
                    bool transferSuccess = comm.postFile1(brfile, ref xmlread);
                    TestUtilities.putLine(string.Format("Transferring {0} from repository to child process", Path.GetFileName(crcvMsg.file)));
                    createMsg(comm, CommMessage.MessageType.reply, crcvMsg.file, "http://localhost:8080/IPluggableComm", crcvMsg.command, crcvMsg.from, "http://localhost:8080/IPluggableComm", null, xmlread);
                }

                if (crcvMsg.type == CommMessage.MessageType.connect)
                    continue;
                if (crcvMsg.type == CommMessage.MessageType.request)
                {
                    byte[] fileread = null;
                    string file = Path.Combine(storagePath, Path.GetFileName(crcvMsg.file));
                    TestUtilities.putLine(string.Format("Transferring file \"{0}\" from repository to child process for processing {1}", crcvMsg.file, Path.GetFileName(crcvMsg.file)));
                    bool transferSuccess = comm.postFile1(file, ref fileread);
                    createMsg(comm, CommMessage.MessageType.request, "send", "http://localhost:8080/IPluggableComm", crcvMsg.file, crcvMsg.from, "http://localhost:8080/IPluggableComm", null, fileread);
                }
                if (crcvMsg.type == CommMessage.MessageType.displayLog)
                {
                    List<string> file_set1 = new List<string>();
                    file_set1 = process_It("*.txt");
                    createMsg(comm, CommMessage.MessageType.request, "logsdisplay", "http://localhost:8080/IPluggableComm", crcvMsg.file, crcvMsg.from, "http://localhost:8080/IPluggableComm", file_set1, null);
                }
                if (crcvMsg.type == CommMessage.MessageType.sendLog)
                {
                    string logfile = Path.Combine("../../RepoStorage", Path.GetFileName(crcvMsg.file));
                    comm.postFile(ref logfile, crcvMsg.block);
                    createMsg(comm, CommMessage.MessageType.sendLog, "log", "http://localhost:8080/IPluggableComm", crcvMsg.file, crcvMsg.from, "http://localhost:8080/IPluggableComm", null, null);
                    Thread.Sleep(500);
                }
            }

            return crcvMsg;
        }

        static void Main(string[] args)
        {
            RepoMock repo = new RepoMock();
            ClientEnvironment.verbose = true;
            TestUtilities.vbtitle("Repository", '=');

            if (args.Count() == 0)
            {
                TestUtilities.checkResult(repo.testComm("stop"), "Comm");
                TestUtilities.putLine("\n GUI start\n");
            }
            else
            {
                TestUtilities.checkResult(repo.testComm(args[0]), "Comm");
                TestUtilities.putLine("\n Batch run start\n");
            }
            TestUtilities.putLine();

            TestUtilities.putLine("Press key to quit\n");
            if (ClientEnvironment.verbose)
                Console.ReadKey();
        }
    }
}

