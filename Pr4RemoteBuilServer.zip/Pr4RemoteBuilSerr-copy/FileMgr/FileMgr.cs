﻿////////////////////////////////////////////////////////////////////////
// FileMgr - provides file and directory handling for navigation      //
//                                                                    //
// Platform:    MSI , Windows 10, Visual Studio 2017                  //
// Author:      Vishnu Prasad Vishwanathan                            //
// Referenece:  Jim Fawcett                                           //
// SUID:        793782749                                             //
//             (315)382-9922,                                         //
//              vvishwan@syr.edu                                      //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017    //
////////////////////////////////////////////////////////////////////////
/* 
 * Package Operations:
 * -------------------
 * 1. Helps in getting Files
 * 2. Helps in acessing Directories
 *  
 *  Required Files:
 * ---------------
 *  
 * Maintenance History:
 * --------------------
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Navigator
{
  public enum FileMgrType { Local, Remote }

  ///////////////////////////////////////////////////////////////////
  // NavigatorClient uses only this interface and factory

  public interface IFileMgr
  {
    void getFiles();                         // IEnumerable<string>
    IEnumerable<string> getDirs();
    bool setDir(string dir);
    Stack<string> pathStack { get; set; }
    string currentPath { get; set; }
  }

  public class FileMgrFactory
  {
    static public IFileMgr create(FileMgrType type)
    {
      if (type == FileMgrType.Local)
        return new LocalFileMgr();
      else
        return null;  // eventually will have remote file Mgr
    }
  }

  ///////////////////////////////////////////////////////////////////
  // Concrete class for managing local files

  public class LocalFileMgr : IFileMgr
  {
    public string currentPath { get; set; } = "";
    public Stack<string> pathStack { get; set; } = new Stack<string>();

    public LocalFileMgr()
    {
      pathStack.Push(currentPath);  // stack is used to move to parent directory
    }

    //----< get names of all files in current directory >------------
    public void getFiles()                 //IEnumerable<string>
    {
 
    }

    //----< get names of all subdirectories in current directory >---

    public IEnumerable<string> getDirs()
    {
      List<string> dirs = new List<string>();
 
      return dirs;
    }

    //----< sets value of current directory - not used >-------------

    public bool setDir(string dir)
    {
      if (!Directory.Exists(dir))
        return false;
      currentPath = dir;
      return true;
    }
  }

  class TestFileMgr
  {
    static void Main(string[] args)
    {
    }
  }
}
